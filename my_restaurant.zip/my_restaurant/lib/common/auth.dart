import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  late SharedPreferences prefs;
  init() async {
    prefs = await SharedPreferences.getInstance();
  }

  bool check() {
    Object? email = prefs.get("email");
    Object? password = prefs.get("password");
    if (email != null && password != null) {
      return true;
    } else {
      return false;
    }
  }

  add({required String email, required String password}) {
    prefs.setString("email", email);
    prefs.setString("password", password);
  }

  logout() {
    prefs.remove("email");
    prefs.remove("password");
  }
}
