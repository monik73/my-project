import 'package:flutter/material.dart';

void popSnackBar(
    {required BuildContext context, Duration? duration, required String text}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      shape: const StadiumBorder(),
      duration: duration ?? const Duration(milliseconds: 500),
      content: Text(text),
      margin: const EdgeInsets.all(7),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
