import 'package:flutter/material.dart';
import 'package:my_restaurant/entry/fast_ship.dart';
import 'package:my_restaurant/entry/image_screen.dart';
import 'package:my_restaurant/entry/logo.dart';
import 'package:my_restaurant/screen/home.dart';

import '../entry/forgot_password.dart';
import '../entry/login.dart';
import '../entry/otp.dart';
import '../entry/signin.dart';
import '../entry/verify.dart';

typedef Router = Widget Function(BuildContext);

Map<String, Router> appRoutes = {
  '/': (context) => const LogoScreen(),
  '/splash': (context) => const ImageScreen(),
  '/ship': (context) => const FastShiping(),
  '/login': (context) => const Login(),
  '/signin': (context) => const Signin(),
  '/forgot': (context) => const ForgotPassword(),
  '/verify': (context) => const VerifyNumber(),
  '/otp': (context) => const OTPVerification(),
  '/home': (context) => const HomeScreen(),
};
