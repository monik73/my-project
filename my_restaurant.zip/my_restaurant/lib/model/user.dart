class AppUser {
  String? email;
  String? password;
  String? phone;
  String? username;
  String? birthdate;

  AppUser(
      {this.email, this.password, this.phone, this.username, this.birthdate});

  AppUser.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    password = json['password'];
    phone = json['phone'];
    username = json['username'];
    birthdate = json['birthdate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['password'] = password;
    data['phone'] = phone;
    data['username'] = username;
    data['birthdate'] = birthdate;
    return data;
  }
}
