import 'package:flutter/cupertino.dart';

enum ActiveCategory { Pizza, Burger }

class Category {
  String name;
  VoidCallback callback;
  ActiveCategory currentCategory;
  Category({
    required this.callback,
    required this.name,
    required this.currentCategory,
  });
}

class FoodItem {
  String name;
  String imageUrl;
  double price;
  bool isFavourite;
  FoodItem({
    required this.name,
    required this.price,
    required this.isFavourite,
    required this.imageUrl,
  });
}
