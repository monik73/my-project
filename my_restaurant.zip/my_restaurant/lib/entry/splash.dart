import 'package:flutter/material.dart';

import 'components/buttons.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: Text(
              'delivered fast food to your door '.toUpperCase(),
              style: const TextStyle(
                fontFamily: 'ubi',
                fontSize: 50,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),
          AppsButton(
            title: 'Log in',
            onPressed: () {
              // RestaurantDB.selectData();
              Navigator.pushNamed(context, '/login');
            },
            width: MediaQuery.of(context).size.width * 0.8,
            height: 65,
            fontSize: 30,
            borderRadius: 50,
          ),
          const SizedBox(
            height: 25,
          ),
          AppsButton(
            title: 'Sign in',
            onPressed: () {
              Navigator.pushNamed(context, '/signin');
            },
            width: MediaQuery.of(context).size.width * 0.8,
            height: 65,
            fontSize: 30,
            borderRadius: 50,
          ),
        ],
      ),
    );
  }
}
