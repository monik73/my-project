import 'package:flutter/material.dart';
import 'package:my_restaurant/entry/components/buttons.dart';

class FastShiping extends StatefulWidget {
  const FastShiping({Key? key}) : super(key: key);

  @override
  State<FastShiping> createState() => _FastShipingState();
}

class _FastShipingState extends State<FastShiping> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children: [
                  const SizedBox(
                    height: 50,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Image.asset("assets/image/dine.png"),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      "Easy Take away and dine in",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 250,
              ),
              AppsButton(
                title: 'Next',
                onPressed: () {
                  Navigator.pushNamed(context, "/login");
                },
                textColor: Colors.black,
                width: MediaQuery.of(context).size.width * 0.80,
                height: 45,
                fontSize: 25,
                borderRadius: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
