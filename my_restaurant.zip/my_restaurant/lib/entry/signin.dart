import 'dart:async';

import 'package:flutter/material.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:motion_toast/resources/arrays.dart';
import 'package:my_restaurant/database/firebase.dart';
import 'package:my_restaurant/model/user.dart';

import 'components/buttons.dart';
import 'components/textformfield.dart';

class Signin extends StatefulWidget {
  const Signin({Key? key}) : super(key: key);

  @override
  _SigninState createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  TextEditingController username = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirm = TextEditingController();
  TextEditingController birthdate = TextEditingController();

  bool isPassword = false;
  bool isTAndC = false;
  bool isPasswordConfirm = false;

  final formKey = GlobalKey<FormState>();

  FirebaseDatabaseService service = FirebaseDatabaseService();

  @override
  void initState() {
    service.initialize();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shadowColor: Colors.transparent,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Create an Account',
                    style: TextStyle(
                      fontFamily: 'ubi',
                      fontSize: 35,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  InputField(
                    controller: username,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "please enter valid username";
                      } else {
                        return null;
                      }
                    },
                    title: 'Username',
                  ),
                  InputFieldNumber(
                    controller: phone,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "please enter valid phone number";
                      } else if (value.length < 10) {
                        return "please enter 10 digit phone number";
                      } else {
                        return null;
                      }
                    },
                    title: 'Phone',
                  ),
                  InputField(
                    controller: email,
                    title: 'Email',
                    validator: (value) {
                      if (value == null ||
                          value.isEmpty ||
                          !RegExp(r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
                              .hasMatch(value)) {
                        return "please enter valid email";
                      } else {
                        return null;
                      }
                    },
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: InputField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return "please enter valid birthdate";
                            } else {
                              return null;
                            }
                          },
                          suffix: IconButton(
                            onPressed: () async {
                              final bod = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1950),
                                lastDate: DateTime(2050),
                              );
                              if (bod != null) {
                                setState(
                                  () {
                                    birthdate.text =
                                        "${bod.day}/${bod.month}/${bod.year}";
                                  },
                                );
                              }
                            },
                            icon: const Icon(
                              Icons.date_range,
                            ),
                          ),
                          controller: birthdate,
                          title: 'Birthdate',
                        ),
                      ),
                    ],
                  ),
                  InputField(
                    isPassword: isPassword,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "please enter valid password";
                      } else if (value.length < 6) {
                        return "please enter 6 digit password";
                      } else {
                        return null;
                      }
                    },
                    onVisibility: (value) {
                      setState(() {
                        isPassword = !value;
                      });
                    },
                    controller: password,
                    title: 'Password',
                  ),
                  InputField(
                    isPassword: isPasswordConfirm,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "please enter valid password";
                      } else if (value.length < 6) {
                        return "please enter 6 digit password";
                      } else {
                        return null;
                      }
                    },
                    onVisibility: (value) {
                      setState(() {
                        isPasswordConfirm = !value;
                      });
                    },
                    controller: confirm,
                    title: 'Confirm Password',
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Wrap(
                    direction: Axis.horizontal,
                    alignment: WrapAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Checkbox(
                            value: isTAndC,
                            onChanged: (value) {
                              if (value != null) {
                                setState(
                                  () {
                                    isTAndC = value;
                                  },
                                );
                              }
                            },
                          ),
                          Wrap(
                            children: const [
                              Padding(
                                padding: EdgeInsets.only(left: 5, right: 5),
                                child: Text(
                                  "Accept",
                                  style: TextStyle(
                                    fontFamily: 'ubi',
                                    fontSize: 17.5,
                                    color: Colors.black,
                                  ),
                                  maxLines: 20,
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              Text(
                                "Terms & Condition",
                                style: TextStyle(
                                  fontFamily: 'ubi',
                                  fontSize: 17.5,
                                  color: Colors.blue,
                                ),
                                maxLines: 20,
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                      const Text(
                        'By Clicking Signing that mean you have accepted our terms & condition ',
                        style: TextStyle(
                          fontFamily: 'ubi',
                          fontSize: 17.5,
                          color: Colors.black,
                        ),
                        maxLines: 20,
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                  AppsButton(
                    title: 'Sign up',
                    onPressed: () async {
                      if (formKey.currentState!.validate()) {
                        bool passwordCondition = false;
                        bool tcCondition = false;

                        if (password.text != confirm.text) {
                          MotionToast.warning(
                            title: const Text("Warning"),
                            animationDuration:
                                const Duration(milliseconds: 1500),
                            animationType: AnimationType.fromTop,
                            position: MotionToastPosition.top,
                            description: const Text("Password must be same"),
                          ).show(context);
                          await Future.delayed(const Duration(seconds: 2));
                          Navigator.pop(context);
                        } else {
                          passwordCondition = true;
                        }
                        if (!isTAndC) {
                          MotionToast.warning(
                            title: const Text("Warning"),
                            animationDuration:
                                const Duration(milliseconds: 1500),
                            animationType: AnimationType.fromTop,
                            position: MotionToastPosition.top,
                            description: const Text("Accept Terms & Condition"),
                          ).show(context);
                          await Future.delayed(
                              const Duration(milliseconds: 1500));
                          Navigator.pop(context);
                        } else {
                          tcCondition = true;
                        }

                        if (passwordCondition && tcCondition) {
                          AppUser user = AppUser(
                            email: email.text.trim(),
                            password: password.text,
                            birthdate: birthdate.text,
                            phone: phone.text,
                            username: username.text,
                          );
                          await service.addUser(
                            user.toJson(),
                          );
                          MotionToast.success(
                            title: const Text("Signin successfully."),
                            animationDuration:
                                const Duration(milliseconds: 1500),
                            animationType: AnimationType.fromTop,
                            position: MotionToastPosition.top,
                            description:
                                const Text("Enter details into login page."),
                          ).show(context);
                          await Future.delayed(
                              const Duration(milliseconds: 1500));
                          Navigator.pop(context);
                          Navigator.pushNamed(context, "/login");
                        }
                      }
                    },
                    width: MediaQuery.of(context).size.width * 0.80,
                    height: 45,
                    fontSize: 25,
                    borderRadius: 25,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
