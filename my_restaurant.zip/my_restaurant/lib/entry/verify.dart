import 'package:flutter/material.dart';

import 'components/buttons.dart';
import 'components/textformfield.dart';

class VerifyNumber extends StatefulWidget {
  const VerifyNumber({Key? key}) : super(key: key);

  @override
  _VerifyNumberState createState() => _VerifyNumberState();
}

class _VerifyNumberState extends State<VerifyNumber> {
  TextEditingController mobile = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shadowColor: Colors.transparent,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const Text(
                'Verify your phone number',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'ubi',
                  fontSize: 38,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(
                height: 25,
              ),
              const Text(
                'We have sent you an SMS with a code to your number',
                style: TextStyle(
                  fontFamily: 'ubi',
                  fontSize: 20,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(
                height: 25,
              ),
              InputFieldNumber(
                controller: mobile,
                title: 'Phone Number',
              ),
              const SizedBox(
                height: 25,
              ),
              AppsButton(
                title: 'Next',
                onPressed: () {
                  Navigator.pushNamed(context, '/otp');
                },
                width: MediaQuery.of(context).size.width * 0.75,
                height: 45,
                fontSize: 20,
                borderRadius: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
