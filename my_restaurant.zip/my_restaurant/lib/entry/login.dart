import 'package:flutter/material.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:motion_toast/resources/arrays.dart';
import 'package:my_restaurant/common/auth.dart';
import 'package:my_restaurant/database/firebase.dart';

import 'components/buttons.dart';
import 'components/textformfield.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> with TickerProviderStateMixin {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  bool isPassword = true;
  final formKey = GlobalKey<FormState>();

  FirebaseDatabaseService service = FirebaseDatabaseService();

  AuthService auth = AuthService();

  @override
  void initState() {
    auth.init();
    service.initialize();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Form(
      key: formKey,
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              height: 400,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/image/food_background.jpg"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SingleChildScrollView(
              child: Container(
                width: double.infinity,
                height: 550,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(50)),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 10.0,
                    right: 10,
                    top: 20,
                    bottom: 10,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Welcome Back',
                        style: TextStyle(
                          fontFamily: 'ubi',
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      const Text(
                        'Login to your account',
                        style: TextStyle(
                          fontFamily: 'ubi',
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.85,
                        child: Column(
                          children: [
                            InputField(
                              controller: email,
                              title: 'Email',
                              validator: (value) {
                                if (value == null ||
                                    value.isEmpty ||
                                    !RegExp(r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
                                        .hasMatch(value)) {
                                  return "please enter valid email";
                                } else {
                                  return null;
                                }
                              },
                            ),
                            InputField(
                              isPassword: isPassword,
                              onVisibility: (value) {
                                setState(() {
                                  print(value);
                                  isPassword = !value;
                                });
                              },
                              controller: password,
                              title: 'Password',
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "please enter valid password";
                                } else if (value.length < 6) {
                                  return "please enter 6 digit password";
                                } else {
                                  return null;
                                }
                              },
                            )
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/forgot');
                        },
                        child: const Text(
                          'Forgot your Password ?',
                          style: TextStyle(
                            fontFamily: 'ubi',
                            fontSize: 17.5,
                            color: Colors.amber,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      AppsButton(
                        title: 'Log in',
                        onPressed: () async {
                          bool isValidCredential =
                              formKey.currentState!.validate();
                          if (isValidCredential) {
                            bool isValid = await service.validateUser(
                              email.text.trim(),
                              password.text,
                            );
                            if (isValid) {
                              auth.add(
                                email: email.text.trim(),
                                password: password.text,
                              );
                              MotionToast.success(
                                title: const Text("Login successfully."),
                                animationDuration:
                                    const Duration(milliseconds: 1500),
                                animationType: AnimationType.fromTop,
                                position: MotionToastPosition.top,
                                description:
                                    const Text("Choose your favourite items"),
                              ).show(context);
                              await Future.delayed(
                                  const Duration(milliseconds: 1500));
                              Navigator.pop(context);

                              Navigator.restorablePushNamedAndRemoveUntil(
                                context,
                                "/home",
                                (route) => false,
                              );
                            } else {
                              MotionToast.error(
                                title:
                                    const Text("Login attempt unsuccessfully."),
                                animationDuration:
                                    const Duration(milliseconds: 1500),
                                animationType: AnimationType.fromTop,
                                position: MotionToastPosition.top,
                                description: const Text("Invalid Credential"),
                              ).show(context);
                              await Future.delayed(
                                const Duration(milliseconds: 1500),
                              );
                              Navigator.pop(context);
                            }
                          }
                        },
                        width: MediaQuery.of(context).size.width * 0.75,
                        height: 45,
                        fontSize: 25,
                        borderRadius: 25,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'Don\'t have an account ? ',
                            style: TextStyle(
                              fontFamily: 'ubi',
                              fontSize: 17.5,
                              color: Colors.grey,
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(context, '/signin');
                            },
                            child: const Text(
                              'Signup',
                              style: TextStyle(
                                fontFamily: 'ubi',
                                fontSize: 20,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    ));
  }
}
