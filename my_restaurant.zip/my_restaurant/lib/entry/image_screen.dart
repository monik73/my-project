import 'package:flutter/material.dart';
import 'package:my_restaurant/entry/components/buttons.dart';

class ImageScreen extends StatefulWidget {
  const ImageScreen({Key? key}) : super(key: key);

  @override
  State<ImageScreen> createState() => ImageScreenState();
}

class ImageScreenState extends State<ImageScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: const [
                      Icon(
                        Icons.phone_android,
                        size: 300,
                      ),
                      Icon(
                        Icons.search_outlined,
                        size: 100,
                        color: Colors.amber,
                      ),
                    ],
                  ),
                  const Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      "Explore your favourite items",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              // const SizedBox(
              //   height: 100,
              // ),
              AppsButton(
                title: 'Next',
                onPressed: () {
                  Navigator.pushNamed(context, "/ship");
                },
                textColor: Colors.black,
                width: MediaQuery.of(context).size.width * 0.80,
                height: 45,
                fontSize: 25,
                borderRadius: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
