import 'dart:async';

import 'package:flutter/material.dart';
import 'package:my_restaurant/common/auth.dart';

class LogoScreen extends StatefulWidget {
  const LogoScreen({Key? key}) : super(key: key);

  @override
  State<LogoScreen> createState() => _LogoScreenState();
}

class _LogoScreenState extends State<LogoScreen> {
  @override
  void initState() {
    Timer(
      const Duration(seconds: 3),
      () async {
        AuthService auth = AuthService();
        await auth.init();
        bool isThereUserExist = auth.check();
        if (isThereUserExist) {
          Navigator.pushNamedAndRemoveUntil(
            context,
            "/home",
            (route) => false,
          );
        } else {
          Navigator.pushNamed(
            context,
            "/splash",
          );
        }
      },
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Image.asset(
          "assets/image/resturant.gif",
        ),
      ),
    );
  }
}
