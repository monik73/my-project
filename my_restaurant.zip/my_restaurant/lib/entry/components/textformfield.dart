import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class InputField extends StatelessWidget {
  TextEditingController controller = TextEditingController();
  String? title;
  bool? isPassword;
  Widget? suffix;
  TextInputType? textInputType;
  ValueChanged<bool>? onVisibility;
  String? Function(String?)? validator;

  InputField({
    Key? key,
    required this.controller,
    this.onVisibility,
    this.isPassword,
    this.suffix,
    this.title,
    this.textInputType,
    this.validator,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: TextFormField(
        keyboardType: textInputType,
        validator: validator,
        controller: controller,
        obscureText: (isPassword == null || isPassword == false) ? false : true,
        decoration: InputDecoration(
          filled: true,
          hintText: title,
          suffixIcon: isPassword == null
              ? suffix
              : IconButton(
                  onPressed: () => onVisibility!(isPassword!),
                  icon: isPassword == false
                      ? const Icon(Icons.visibility)
                      : const Icon(Icons.visibility_off),
                ),
          hintStyle: const TextStyle(
            fontFamily: 'ubi',
            fontSize: 17,
            fontWeight: FontWeight.bold,
            color: Colors.black38,
          ),
          contentPadding: const EdgeInsets.only(left: 20),
          fillColor: const Color(0xffF0F0F2),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}

class InputFieldNumber extends StatelessWidget {
  TextEditingController controller;
  String? Function(String?)? validator;
  String? title;
  InputFieldNumber({
    Key? key,
    required this.controller,
    this.validator,
    this.title,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: TextInputType.number,
        inputFormatters: <TextInputFormatter>[
          FilteringTextInputFormatter.digitsOnly
        ],
        decoration: InputDecoration(
          filled: true,
          hintText: title,
          hintStyle: const TextStyle(
            fontFamily: 'ubi',
            fontSize: 17,
            fontWeight: FontWeight.bold,
            color: Colors.black38,
          ),
          contentPadding: const EdgeInsets.only(left: 20),
          fillColor: const Color(0xffF0F0F2),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
