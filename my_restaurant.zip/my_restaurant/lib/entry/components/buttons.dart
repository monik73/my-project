import 'package:flutter/material.dart';

class AppsButton extends StatelessWidget {
  String title;
  double? width;
  double? height;
  double? borderRadius;
  VoidCallback onPressed;
  Color? color;
  Color? textColor;
  double? fontSize;
  AppsButton({
    Key? key,
    required this.title,
    required this.onPressed,
    this.width,
    this.height,
    this.color,
    this.borderRadius,
    this.fontSize,
    this.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all(color),
        fixedSize: MaterialStateProperty.all(
          Size(width!, height!),
        ),
        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(borderRadius!),
          ),
        ),
      ),
      child: Text(
        title,
        style: TextStyle(
          fontFamily: 'ubi',
          fontSize: fontSize,
          color: textColor,
        ),
      ),
    );
  }
}
