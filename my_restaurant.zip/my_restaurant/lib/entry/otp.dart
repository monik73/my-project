import 'package:flutter/material.dart';
import 'package:my_restaurant/entry/components/buttons.dart';
import 'package:my_restaurant/entry/components/textformfield.dart';

class OTPVerification extends StatefulWidget {
  const OTPVerification({Key? key}) : super(key: key);

  @override
  _OTPVerificationState createState() => _OTPVerificationState();
}

class _OTPVerificationState extends State<OTPVerification> {
  TextEditingController otp = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        shadowColor: Colors.transparent,
        backgroundColor: Colors.transparent,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const Text(
                  'Email Verification',
                  style: TextStyle(
                    fontFamily: 'ubi',
                    fontSize: 35,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const Text(
                  'Enter your OTP code here',
                  style: TextStyle(
                    fontFamily: 'ubi',
                    fontSize: 18,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: InputField(
                    controller: otp,
                    title: "OTP",
                    textInputType: TextInputType.number,
                  ),
                ),
                const Text(
                  "You can see OTP on your email address",
                ),
                const SizedBox(
                  height: 25,
                ),
                const Text(
                  'Don\'t share your OTP code with any other',
                  style: TextStyle(
                    fontFamily: 'ubi',
                    fontSize: 18,
                    color: Colors.black,
                  ),
                  textAlign: TextAlign.center,
                ),
                TextButton(
                  onPressed: () {},
                  child: const Text(
                    'Resend a New Code',
                    style: TextStyle(
                      fontFamily: 'ubi',
                      fontSize: 18,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  height: 25,
                ),
                AppsButton(
                  title: 'Submit',
                  onPressed: () {
                    Navigator.pushNamed(context, "/login");
                  },
                  width: MediaQuery.of(context).size.width * 0.75,
                  height: 45,
                  fontSize: 20,
                  borderRadius: 25,
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.4,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
