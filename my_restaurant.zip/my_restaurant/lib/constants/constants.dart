class Constants {
  static String inr = "\u{20B9}";
}
