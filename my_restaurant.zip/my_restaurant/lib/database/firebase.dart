import 'package:firebase_database/firebase_database.dart';

class FirebaseDatabaseService {
  FirebaseDatabase db = FirebaseDatabase.instance;
  late DatabaseReference databaseReference;
  initialize() {
    databaseReference = db.ref("users");
  }

  addUser(Map<String, dynamic> json) async {
    await databaseReference.push().set(json);
  }

  Future<bool> validateUser(String email, String password) async {
    var data = await databaseReference.get();
    var response = data.children.toList();

    for (int i = 0; i < response.length; i++) {
      if ((response[i].value as Map)["email"] == email &&
          (response[i].value as Map)["password"] == password) {
        return true;
      }
    }
    return false;
  }
}
