import 'package:flutter/material.dart';
import 'package:my_restaurant/model/others.dart';
import 'package:my_restaurant/screen/food.dart';

class AppHomeScreen extends StatefulWidget {
  const AppHomeScreen({Key? key}) : super(key: key);

  @override
  State<AppHomeScreen> createState() => App_HomeStateScreen();
}

class App_HomeStateScreen extends State<AppHomeScreen> {
  int pizza = 10;
  int burger = 6;
  bool isPizza = true;
  ActiveCategory activeCategory = ActiveCategory.Pizza;
  int currentItems = 10;
  List<Category> category = [];
  List<FoodItem> foods = [];
  List<FoodItem> pizzaFood = [
    FoodItem(
      name: "Cheese Pizza",
      imageUrl: "assets/image/cheese-pizza.png",
      price: 23,
      isFavourite: false,
    ),
    FoodItem(
      name: "Onion Pizza",
      imageUrl: "assets/image/onion-pizza.png",
      price: 26,
      isFavourite: false,
    ),
    FoodItem(
      name: "Tomato Pizza",
      imageUrl: "assets/image/tomato-pizza.png",
      price: 28,
      isFavourite: false,
    ),
    FoodItem(
      name: "Periperi Pizza",
      imageUrl: "assets/image/periperi-pizza.png",
      price: 21,
      isFavourite: false,
    ),
    FoodItem(
      name: "Cheese Pizza ",
      imageUrl: "assets/image/cheese-pizza.png",
      price: 23,
      isFavourite: false,
    ),
    FoodItem(
      name: "Onion Pizza ",
      imageUrl: "assets/image/onion-pizza.png",
      price: 26,
      isFavourite: false,
    ),
    FoodItem(
      name: "Tomato Pizza ",
      imageUrl: "assets/image/tomato-pizza.png",
      price: 28,
      isFavourite: false,
    ),
    FoodItem(
      name: "Periperi Pizza ",
      imageUrl: "assets/image/periperi-pizza.png",
      price: 21,
      isFavourite: false,
    ),
  ];
  List<FoodItem> burgerFood = [
    FoodItem(
      name: "Cheese Burger",
      imageUrl: "assets/image/cheese-burger.png",
      price: 23,
      isFavourite: false,
    ),
    FoodItem(
      name: "Veg Burger",
      price: 26,
      imageUrl: "assets/image/veg-burger.png",
      isFavourite: false,
    ),
    FoodItem(
      name: "Aloo Tikki Burger",
      imageUrl: "assets/image/aloo-tikki-burger.png",
      price: 28,
      isFavourite: false,
    ),
    FoodItem(
      name: "Tandoori Burger",
      imageUrl: "assets/image/tandoori-burger.png",
      price: 21,
      isFavourite: false,
    ),
    FoodItem(
      name: "Cheese Burger ",
      imageUrl: "assets/image/cheese-burger.png",
      price: 23,
      isFavourite: false,
    ),
    FoodItem(
      name: "Veg Burger ",
      price: 26,
      imageUrl: "assets/image/veg-burger.png",
      isFavourite: false,
    ),
    FoodItem(
      name: "Aloo Tikki Burger ",
      imageUrl: "assets/image/aloo-tikki-burger.png",
      price: 28,
      isFavourite: false,
    ),
    FoodItem(
      name: "Tandoori Burger ",
      imageUrl: "assets/image/tandoori-burger.png",
      price: 21,
      isFavourite: false,
    ),
  ];

  @override
  void initState() {
    foods = pizzaFood;
    category = [
      Category(
          currentCategory: ActiveCategory.Pizza,
          callback: () {
            setState(
              () {
                foods = pizzaFood;
                activeCategory = ActiveCategory.Pizza;
              },
            );
          },
          name: "Pizza"),
      Category(
          currentCategory: ActiveCategory.Burger,
          callback: () {
            setState(
              () {
                foods = burgerFood;
                activeCategory = ActiveCategory.Burger;
              },
            );
          },
          name: "Burger"),
    ];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("My Restaurant"),
      ),
      body: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: category.map(
              (e) {
                return GestureDetector(
                  onTap: e.callback,
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: Chip(
                      backgroundColor: activeCategory == e.currentCategory
                          ? Colors.amber
                          : null,
                      label: Padding(
                        padding: const EdgeInsets.only(left: 5, right: 5),
                        child: Text(
                          e.name,
                          style: const TextStyle(
                            fontSize: 25,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ).toList(),
          ),
          Expanded(
            child: GridView.builder(
              physics: const BouncingScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2),
              itemCount: foods.length,
              itemBuilder: (context, index) {
                return Stack(
                  children: [
                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 8,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Expanded(
                              child: Hero(
                                tag: foods[index],
                                child: GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          return FoodScreen(
                                            foodItem: foods[index],
                                          );
                                        },
                                      ),
                                    );
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(12.0),
                                    child: Image.asset(
                                      foods[index].imageUrl,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  foods[index].name,
                                  style: const TextStyle(
                                    fontSize: 16.5,
                                  ),
                                ),
                                Text(
                                  " \$${foods[index].price}",
                                  style: const TextStyle(
                                    fontSize: 19,
                                    color: Colors.green,
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: IconButton(
                          onPressed: () {
                            setState(
                              () {
                                foods[index].isFavourite =
                                    !foods[index].isFavourite;
                              },
                            );
                          },
                          icon: Icon(
                            foods[index].isFavourite
                                ? Icons.favorite
                                : Icons.favorite_outline,
                          ),
                          color: foods[index].isFavourite
                              ? Colors.red
                              : Colors.black,
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
