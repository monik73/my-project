import 'package:flutter/material.dart';
import 'package:my_restaurant/common/auth.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  AuthService auth = AuthService();

  @override
  void initState() {
    auth.init();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Account",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 25,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 50,
              ),
              const Text(
                "username",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 25,
                ),
              ),
              Column(
                children: [
                  IconButton(
                    onPressed: () {
                      auth.logout();
                      Navigator.pushReplacementNamed(context, "/");
                    },
                    iconSize: 30,
                    icon: const Icon(
                      Icons.logout,
                    ),
                  ),
                  const Text(
                    "Logout",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20),
                  ),
                ],
              )
            ]
                .map(
                  (e) => Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: e,
                  ),
                )
                .toList(),
          ),
        ),
      ),
    );
  }
}
