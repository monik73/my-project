import 'package:flutter/material.dart';
import 'package:my_restaurant/model/others.dart';
import 'package:my_restaurant/screen/success.dart';

class FoodScreen extends StatefulWidget {
  final FoodItem foodItem;
  const FoodScreen({Key? key, required this.foodItem}) : super(key: key);

  @override
  State<FoodScreen> createState() => _FoodScreenState();
}

class _FoodScreenState extends State<FoodScreen> {
  int qty = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            title: Text(
              widget.foodItem.name,
              style: const TextStyle(),
            ),
            backgroundColor: Colors.transparent,
            leading: IconButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: const Icon(
                Icons.arrow_back_ios,
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate(
              [
                Hero(
                  tag: widget.foodItem,
                  child: Image.asset(
                    widget.foodItem.imageUrl,
                    fit: BoxFit.contain,
                    height: 400,
                    width: MediaQuery.of(context).size.width,
                    filterQuality: FilterQuality.high,
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Card(
                    shape: const StadiumBorder(),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          IconButton(
                            onPressed: () {
                              setState(() {
                                if (qty == 0) {
                                } else {
                                  qty--;
                                }
                              });
                            },
                            icon: const Icon(
                              Icons.remove,
                              size: 25,
                            ),
                          ),
                          Text(
                            '$qty',
                            style: const TextStyle(
                              fontSize: 25,
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              setState(() {
                                qty++;
                              });
                            },
                            icon: const Icon(
                              Icons.add,
                              size: 25,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.foodItem.name,
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      " \$${widget.foodItem.price}",
                      style: const TextStyle(
                        fontSize: 25,
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const Divider(
                  indent: 2,
                  thickness: 2,
                  height: 5,
                  color: Colors.black,
                ),
                qty == 0
                    ? const SizedBox()
                    : Card(
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.black, width: 1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        elevation: 5,
                        color: Colors.amber[50],
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              const Text(
                                'Receipt',
                                style: TextStyle(
                                  fontSize: 25,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Row(
                                children: [
                                  const Expanded(
                                    flex: 7,
                                    child: Text(
                                      'Quantity',
                                      style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.black87,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 3,
                                    child: Text(
                                      'x $qty',
                                      style: const TextStyle(
                                        fontSize: 20,
                                        color: Colors.black87,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  const Expanded(
                                    flex: 7,
                                    child: Text(
                                      'Total',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 3,
                                    child: Text(
                                      '\$ ${widget.foodItem.price * qty}',
                                      style: const TextStyle(
                                        fontSize: 20,
                                        color: Colors.black87,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ]
                                .map(
                                  (e) => Padding(
                                    padding: const EdgeInsets.all(5.0),
                                    child: e,
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber,
                      fixedSize:
                          Size(MediaQuery.of(context).size.width / 2.25, 55),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) {
                            return const SuccessScreen();
                          },
                        ),
                      );
                    },
                    child: const Text(
                      "Order now",
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              ]
                  .map(
                    (e) => Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: e,
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}
