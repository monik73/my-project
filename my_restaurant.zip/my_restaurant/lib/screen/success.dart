import 'package:flutter/material.dart';
import 'package:my_restaurant/screen/home.dart';

class SuccessScreen extends StatefulWidget {
  const SuccessScreen({Key? key}) : super(key: key);

  @override
  State<SuccessScreen> createState() => _SuccessScreenState();
}

class _SuccessScreenState extends State<SuccessScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(
              height: 100,
            ),
            const Text(
              "Hurray !",
              style: TextStyle(
                fontSize: 35,
                color: Colors.amber,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              "Order Confirm",
              style: TextStyle(
                fontSize: 25,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(50.0),
              child: Image.asset("assets/image/yellow-success.gif"),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber,
                  fixedSize: Size(MediaQuery.of(context).size.width / 2.25, 55),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return const HomeScreen();
                      },
                    ),
                    (route) => false,
                  );
                },
                child: const Text(
                  "Go to Home",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
