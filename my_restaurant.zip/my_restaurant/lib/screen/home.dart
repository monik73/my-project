import 'package:flutter/material.dart';
import 'package:my_restaurant/screen/account.dart';
import 'package:my_restaurant/screen/home_screen.dart';

class HomeScreen extends StatefulWidget {
  final int? push;
  const HomeScreen({Key? key, this.push}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  PageController pageController = PageController();
  int bottomIndex = 0;

  List<BottomSet> bottomSet = [
    BottomSet(
      label: 'Home',
      icon: Icons.home,
    ),
    BottomSet(
      label: 'Favourite',
      icon: Icons.favorite,
    ),
    BottomSet(
      label: 'Orders',
      icon: Icons.shop,
    ),
    BottomSet(
      label: 'Account',
      icon: Icons.person,
    ),
  ];

  pushToPage() {
    widget.push == null ? true : pageController.jumpToPage(widget.push!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: buildBody(),
      resizeToAvoidBottomInset: false,
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          labelTextStyle: MaterialStateProperty.all(
            const TextStyle(
              fontFamily: 'ubi',
              color: Colors.black,
            ),
          ),
          backgroundColor: Colors.amber[50],
          indicatorColor: Colors.amber[100],
          height: 60,
        ),
        child: NavigationBar(
          onDestinationSelected: (value) {
            bottomIndex = value;

            pageController.jumpToPage(value);
            setState(
              () {},
            );
          },
          selectedIndex: bottomIndex,
          destinations: bottomSet
              .map(
                (e) => NavigationDestination(
                  icon: Icon(
                    e.icon,
                  ),
                  label: e.label,
                ),
              )
              .toList(),
        ),
      ),
    );
  }

  Widget buildBody() {
    return PageView(
      controller: pageController,
      onPageChanged: (value) {
        bottomIndex = value;
        setState(() {});
      },
      children: const [
        AppHomeScreen(),
        Scaffold(),
        Scaffold(),
        AccountScreen()
      ],
    );
  }
}

class BottomSet {
  IconData? icon;
  String label;
  BottomSet({this.icon, required this.label});
}
