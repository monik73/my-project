import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:my_restaurant/firebase_options.dart';

import 'common/routes.dart';

Future<void> main(List<String> args) async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const FoodApp());
}

class FoodApp extends StatelessWidget {
  const FoodApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: "ubi",
        primarySwatch: Colors.amber,
      ),
      initialRoute: '/',
      routes: appRoutes,
    );
  }
}
