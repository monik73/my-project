package com.example.my_restaurant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
